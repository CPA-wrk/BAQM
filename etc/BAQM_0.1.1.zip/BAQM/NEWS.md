# BAQM 0.1.1

* Initial CRAN submission.
